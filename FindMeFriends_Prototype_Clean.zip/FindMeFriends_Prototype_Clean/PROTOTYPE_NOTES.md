# FindMe Friends Prototype Notes (HW2/HW4)

## What was implemented

### Node.js API (`prototype/server/`)

Runs locally as the application server from the architecture PDF. Uses HTTP on localhost for development; production would use HTTPS plus JSON.

| Endpoint | Purpose | Requirement |
| --- | --- | --- |
| `POST /api/register` | Real-name registration | Real names, ID flow |
| `POST /api/login` | Session start | Auth |
| `POST /api/id-verify` | Mock ID vendor | ID-based registration |
| `POST /api/location` | Lat/lon updates | Geolocation connector |
| `GET /api/nearby` | Distance + filters + range | Map, filters, discovery range |
| `PATCH /api/profile/:userId` | Bio, public/private | Bios, privacy |
| `GET /api/settings/:userId` | Read range, privacy, filters | Settings use cases |
| `PATCH /api/settings/:userId` | Update range, privacy, filters | Settings use cases |
| `GET /api/activities` | Recurring groups | Activities tab |
| `POST /api/activities/:id/join` | Capacity check | Group size/capacity |
| `GET /api/chat/threads/:userId` | Thread list | Chat feature |
| `GET /api/chat/:userId/:otherUserId` | Conversation messages | Chat feature |
| `POST /api/chat/:userId/:otherUserId` | Send message | Chat feature |
| `POST /api/chat/:userId/:otherUserId/report` | Mock report/block | Chat safety flow |

Data is stored in in-memory `Map` objects as a prototype stand-in for SQL tables.

Seeded demo users:

```text
alice@example.edu / demo123
bob@example.edu / demo123
casey@example.edu / demo123
```

### Expo React Native app (`prototype/mobile/`)

Matches the architecture PDF: Expo + React Native for Android/iOS, with web enabled for easy local browser testing.

| Screen | Features |
| --- | --- |
| Login / Register | Email login; 3-step register: name, account, mock ID upload |
| Discover (Map) | Mock map UI, nearby list, privacy display, message link |
| Activities | Browse/join recurring groups; capacity errors |
| Chat | Thread list, conversation, report/block mock |
| Profile | Edit bio, prompts, public/private |
| Settings | Discovery range, age/gender filters, expand search |

### CLI stub (`prototype/client-stub/`)

Original HW2 loop client preserved for architecture reflection and headless testing.

---

## What is mocked

| Component | Prototype | Production direction |
| --- | --- | --- |
| Database | In-memory `Map` | SQL, such as PostgreSQL |
| Google Maps | `MockMap` component | Vendor Maps SDK + HTTPS API |
| ID verification | Accepts mock base64 string | External verification service |
| HTTPS | HTTP on localhost | TLS on PaaS/cloud |
| Python geo helpers | Not used; Node only | Optional microservices per PDF |
| Push notifications | Not implemented | Future chat/notification flow |

---

## How to run the current prototype

Run the API server and the app in **two separate PowerShell windows**. Start the API first, then start the Expo app.

Windows PowerShell note: use `npm.cmd` and `npx.cmd` on this machine. Plain `npm` / `npx` may fail if PowerShell script execution is disabled.

### Window 1: Start the API server

```powershell
cd C:\Users\hjm03\OneDrive\Desktop\INF43\prototype\server
npm.cmd install
npm.cmd start
```

Leave this window running. You should see:

```text
FindMe API listening on http://localhost:3000
Demo login: alice@example.edu / demo123
```

Server URL: `http://localhost:3000`

Health check: `GET /health`

### Window 2: Start the app in a browser

```powershell
cd C:\Users\hjm03\OneDrive\Desktop\INF43\prototype\mobile
npm.cmd install
npx.cmd expo start --web --port 8083
```

Open this URL in your browser:

```text
http://localhost:8083
```

Demo login:

```text
Email: alice@example.edu
Password: demo123
```

### Mobile / Expo Go option

You can also run the Expo app on an Android emulator or a physical phone.

Android emulator:

```powershell
cd C:\Users\hjm03\OneDrive\Desktop\INF43\prototype\mobile
npx.cmd expo start
```

Then press **a** in the Expo terminal.

Physical device with Expo Go:

1. Make sure your phone and computer are on the same network.
2. Set the API URL to your computer's LAN IP before starting Expo:

```powershell
$env:EXPO_PUBLIC_API_URL="http://YOUR_PC_IP:3000"
npx.cmd expo start
```

3. Scan the QR code with Expo Go.

Android emulator networking uses `http://10.0.2.2:3000` automatically through the app config.

### Optional: CLI stub

```powershell
cd C:\Users\hjm03\OneDrive\Desktop\INF43\prototype\client-stub
$env:USER_ID="user-a"; node send-location.js
```

---

## How to run tests

The current tests follow the HW4 testing writeup snapshot style.

```powershell
cd C:\Users\hjm03\OneDrive\Desktop\INF43\prototype\server
node --test tests\*.test.js
node --experimental-test-coverage --test tests\*.test.js
```

Current snapshot label:

```text
Last updated: 2026-05-27 (commit unavailable - workspace is not a Git repo)
```

Current result: 15 tests passing.

Measured coverage snapshot: `store.js` line 96.76%, branch 75.00%, functions 77.78%.

Coverage documentation lives at:

```text
C:\Users\hjm03\OneDrive\Desktop\INF43\coverage\index.html
```

Test plan and implementation report:

```text
C:\Users\hjm03\OneDrive\Desktop\INF43\docs\TEST_PLAN.md
```

---

## Requirements traceability

| Document | Satisfied by |
| --- | --- |
| `requirements_specification.md` | Features above + use-case flows: range in Settings, bio moderation stub, filter empty state, activity capacity, chat report |
| `INF 43 Friend Finder Design.pdf` | Expo client, Node API, JSON, SQL stub, mock maps/ID |
| `HW2 Directions.txt` | Prototype + reflection material; stub client kept |
| `HW4_ Testing.pdf` | Unit tests, integration tests, dated coverage snapshot, and test plan/report |
| `README.md` meeting log | Prototype supports subset of decided features |

---

## Known limitations

- No real password hashing or JWT; this is prototype-only auth.
- Nearby search is O(n) linear scan on the server.
- Chat does not persist after server restart because storage is in-memory.
- SQL, Google Maps, ID verification, and push notifications are still mocked or not implemented.
- Node's built-in coverage reports `store.js` directly; Express endpoint behavior is covered through black-box integration tests.
- `node_modules/` should not be committed.

