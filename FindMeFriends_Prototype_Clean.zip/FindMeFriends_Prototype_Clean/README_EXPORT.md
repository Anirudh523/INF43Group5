# FindMe Friends Prototype Export

This folder is a clean teammate-ready copy of the FindMe Friends prototype.

It includes:

- Prototype source code in `prototype/`
- Server tests in `prototype/server/tests/`
- HW4 test plan in `docs/TEST_PLAN.md`
- Coverage snapshot in `coverage/index.html`
- Project writeups and design PDFs
- Package lock files so dependencies install consistently

It intentionally excludes:

- `node_modules/`
- Expo cache folders
- build/dist output
- extracted PowerPoint internals

## Run the Prototype

Open two PowerShell windows.

### Window 1: API server

```powershell
cd prototype\server
npm.cmd install
npm.cmd start
```

Leave this running. Expected output:

```text
FindMe API listening on http://localhost:3000
Demo login: alice@example.edu / demo123
```

### Window 2: App in browser

```powershell
cd prototype\mobile
npm.cmd install
npx.cmd expo start --web --port 8083
```

Open:

```text
http://localhost:8083
```

Demo login:

```text
Email: alice@example.edu
Password: demo123
```

## Run Tests

```powershell
cd prototype\server
node --test tests\*.test.js
node --experimental-test-coverage --test tests\*.test.js
```

Current snapshot:

```text
Last updated: 2026-05-27 (commit unavailable - workspace is not a Git repo)
15 tests passing
store.js coverage: 96.76% line, 75.00% branch, 77.78% functions
```

## Notes

Use `npm.cmd` and `npx.cmd` on Windows PowerShell if plain `npm` or `npx` is blocked by script execution policy.

For full details, read `PROTOTYPE_NOTES.md`.
