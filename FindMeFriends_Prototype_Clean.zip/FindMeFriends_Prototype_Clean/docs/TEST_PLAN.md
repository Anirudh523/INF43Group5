# FindMe Friends Test Plan

Last updated: 2026-05-27 (commit unavailable - workspace is not a Git repo)

## Part 1 - Strategic Test Plan

### 1.1 Scope

In scope:

| Area | Why this matters |
| --- | --- |
| Node API registration, login, profile, settings, nearby discovery, activities, and chat | These are the prototype features connected to the HW1/HW2 requirements. |
| In-memory store helpers | Current mocked SQL replacement; bugs here affect discovery, privacy, chat, and seed data. |
| Mock ID verification and profile moderation paths | These represent safety features that will later connect to external services. |
| Basic mobile/API contract assumptions | The Expo app depends on the response shapes from `src/api/client.ts`. |

Out of scope for the current snapshot:

| Area | Why excluded |
| --- | --- |
| Real SQL persistence | The current prototype intentionally uses in-memory `Map` objects. |
| Real Google Maps SDK behavior | The app currently uses `MockMap`; vendor map behavior should be tested after integration. |
| Real ID vendor verification accuracy | The current endpoint accepts/rejects only a mock base64 string. |
| Push notifications | Not implemented in the prototype. |
| Cross-browser/device matrix | This snapshot focuses on local Node API behavior, not full UI automation. |

### 1.2 Quality Goals

- No critical failures in demo login, nearby discovery, activity joining, profile save/moderation, or chat send.
- Unit tests cover the mocked store's distance, privacy, filter, chat-key, seed-data, and create-user helpers.
- Integration tests verify at least three real HTTP flows against the current Express server.
- Test runs should be copy-pasteable on Windows PowerShell using `node --test`.
- Current metrics are dated so later snapshots can evolve without rewriting history.

### 1.3 Risks and Priorities

| Area | Why it is risky / costly | Priority |
| --- | --- | --- |
| Location + filtering logic | Incorrect filtering could show unsafe or irrelevant people. | H |
| Profile privacy | Private bios must not leak in discovery. | H |
| Registration / ID verification | Safety feature, currently mocked and likely to change. | H |
| Chat/report behavior | User safety and harassment reporting depend on correct flow. | M |
| Activity capacity | Overbooking groups breaks trust in recurring activities. | M |
| Real persistence migration | Moving from `Map` to SQL can change behavior. | M |
| Visual polish on mock map | Cosmetic while still mocked. | L |

### 1.4 Strategy

Unit test: a focused test for one small piece of logic, isolated from HTTP, UI, or external services.

Integration test: a test that runs multiple parts together, such as the Express server plus its in-memory store through real HTTP requests.

| Component | Test types | Framework | Why this fit |
| --- | --- | --- | --- |
| Backend store (`store.js`) | Unit | Node built-in `node:test` + `assert` | No dependency install required; directly tests current helper behavior. |
| Backend API (`index.js`) | Integration | Node built-in `node:test`, `fetch`, spawned Node process | Tests the existing server without changing product exports. |
| Mobile API client | Planned contract/unit tests | Future Jest or Node tests with mocked `fetch` | Useful next step, but not required for this backend-focused snapshot. |
| UI screens | Planned component/e2e tests | Future React Native Testing Library or Playwright web | Needs additional test dependencies and more time. |
| Database | Planned integration tests after SQL migration | Future test DB | Current DB is mocked with `Map`. |

### 1.5 Environment and Assumptions

- Local Windows PowerShell environment.
- Node uses the version already available on this machine.
- Tests assume the current in-memory data model and seeded demo users.
- Integration tests start their own API process on port `4317`.
- External services are mocked or absent: SQL, Google Maps, ID verification, and notifications.
- No Git commit hash is available because this folder is not currently a Git repository.

### 1.6 Team Roles

| Member | Owns which test categories / components |
| --- | --- |
| Jungmin Han | Backend API smoke/integration tests and test documentation snapshot. |
| Keya Negandhi | Registration, real-name, and ID-verification test cases. |
| Makani Melendrez | Discovery range, filters, and privacy test cases. |
| Daniel Tan | Chat, report/block, and profile moderation test cases. |
| Anirudh Ravishankar | Activities, capacity, and future UI/e2e test cases. |

## Part 2 - Tests Implemented and Report

### 2.1 Required Minimums

Last updated: 2026-05-27 (commit unavailable - workspace is not a Git repo)

| Category | Required minimum | Current count |
| --- | ---: | ---: |
| Unit tests | 5 | 9 |
| Integration tests | 3 | 6 |

### 2.3 Tests by Category

Last updated: 2026-05-27 (commit unavailable - workspace is not a Git repo)

| Category | Count | Examples |
| --- | ---: | --- |
| Unit | 9 | `haversineKm` OC distance, private profile bio hiding, gender/age filter matching |
| Integration | 6 | demo login, nearby discovery privacy fields, chat send/read persistence |

### 2.4 Where Tests Live and How To Run Them

Test files:

```text
prototype/server/tests/store.test.js
prototype/server/tests/api.integration.test.js
```

Run from `prototype/server`:

```powershell
cd C:\Users\hjm03\OneDrive\Desktop\INF43\prototype\server
node --test tests\*.test.js
node --experimental-test-coverage --test tests\*.test.js
```

Approximate runtimes:

| Category | Time | Where it runs |
| --- | --- | --- |
| Unit | Less than 1 second | Local Windows PowerShell |
| Integration | About 1 second | Local Windows PowerShell, starts API on port `4317` |

### 2.5 Coverage Achieved

Last updated: 2026-05-27 (commit unavailable - workspace is not a Git repo)

| Test type | Tool | Coverage |
| --- | --- | --- |
| Unit | `node --experimental-test-coverage --test tests\*.test.js` | `store.js`: 96.76% line, 75.00% branch, 77.78% function coverage. |
| Integration | Black-box HTTP tests | Endpoint behavior covered; child process source coverage is not counted by Node's parent process coverage summary. |
| Combined | Node built-in runner + manual HTML snapshot | 15 tests passing; measured coverage snapshot stored in `coverage/index.html`. |

Not covered yet:

- Real SQL behavior, because storage is still an in-memory mock.
- Real Google Maps and ID vendor behavior, because both are explicitly mocked.
- Expo UI component tests, because this snapshot avoids adding test dependencies beyond Node's built-in runner.
- Load/concurrency testing, because the HW4 minimum is currently unit + integration coverage.

### 2.6 Plan-vs-Implementation Gap

| Plan called for | Actually shipped | Blocked by / next step |
| --- | --- | --- |
| Backend unit tests | Store/helper unit tests shipped | Add API-handler unit tests after `index.js` is refactored to export `app`. |
| Backend integration tests | Black-box HTTP tests shipped | Good enough for current prototype. |
| Mobile component tests | Not shipped | Would require adding React Native test tooling. |
| SQL persistence tests | Not shipped | SQL is not implemented yet. |
| Real maps/ID tests | Not shipped | External integrations are mocked. |

## Part 3 - Reflection

The tests caught one important prototype concern before future work: the current chat and profile behavior is process-local because the server stores everything in memory. The chat integration test proves messages persist inside the same running server process, but that same test also documents the limitation that messages disappear after restart. The hardest area to test cleanly was the Express API because `index.js` starts listening immediately instead of exporting an `app` object. To avoid changing product code, the integration tests spawn the server as a separate process and test it through HTTP, which is realistic but makes source coverage less precise. The next test to add would be a registration-to-ID-verification integration flow that creates a user, rejects a bad mock ID, accepts a good mock ID, and confirms login/profile behavior after verification. Codex helped by translating the HW4 requirements into dated, runnable test snapshots and by choosing Node's built-in test runner to avoid extra dependencies. The main limitation is that coverage reporting is not as polished as a full Jest/c8 setup; a future pass should add a standard coverage reporter after the team decides whether extra dev dependencies are acceptable.
