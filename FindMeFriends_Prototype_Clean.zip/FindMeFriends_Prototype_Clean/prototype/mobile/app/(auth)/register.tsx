import { router } from "expo-router";
import { useState } from "react";
import { Alert, StyleSheet, Text, View } from "react-native";
import { api } from "../../src/api/client";
import { Button } from "../../src/components/Button";
import { Input } from "../../src/components/Input";
import { Screen } from "../../src/components/Screen";
import { useAuth } from "../../src/context/AuthContext";
import { colors } from "../../src/theme/colors";

const INTERESTS = ["hiking", "study", "skiing", "sports", "language", "coffee"];

export default function RegisterScreen() {
  const { signIn } = useAuth();
  const [step, setStep] = useState(1);
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [userId, setUserId] = useState("");
  const [picked, setPicked] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  function toggleInterest(i: string) {
    setPicked((prev) => (prev.includes(i) ? prev.filter((x) => x !== i) : [...prev, i]));
  }

  async function submitNames() {
    setError("");
    if (!firstName.trim() || !lastName.trim()) {
      setError("Real first and last name required.");
      return;
    }
    setStep(2);
  }

  async function submitAccount() {
    setError("");
    const id = userId.trim() || email.split("@")[0];
    setLoading(true);
    try {
      await api.register({
        userId: id,
        email: email.trim(),
        password,
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        interests: picked,
      });
      setUserId(id);
      setStep(3);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Registration failed");
    } finally {
      setLoading(false);
    }
  }

  async function submitIdMock() {
    setLoading(true);
    try {
      const mockImage = "data:image/jpeg;base64,mock-government-id-verification-stub";
      await api.verifyId(userId, mockImage);
      await signIn({
        userId,
        displayName: `${firstName} ${lastName}`,
        idVerified: true,
      });
      Alert.alert("Verified", "ID approved (mock verification service).");
      router.replace("/(tabs)/map");
    } catch (e) {
      setError(e instanceof Error ? e.message : "ID verification failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <Screen scroll>
      <Text style={styles.title}>Create account</Text>
      <Text style={styles.step}>Step {step} of 3</Text>

      {step === 1 && (
        <>
          <Text style={styles.info}>
            Government-issued ID is required for safety (mocked in this prototype).
          </Text>
          <Input label="First name" value={firstName} onChangeText={setFirstName} />
          <Input label="Last name" value={lastName} onChangeText={setLastName} error={error} />
          <Button title="Continue" onPress={submitNames} />
        </>
      )}

      {step === 2 && (
        <>
          <Input label="Email" autoCapitalize="none" value={email} onChangeText={setEmail} />
          <Input label="Password" secureTextEntry value={password} onChangeText={setPassword} />
          <Input
            label="Username (optional)"
            value={userId}
            onChangeText={setUserId}
            placeholder="Defaults to email prefix"
          />
          <Text style={styles.label}>Subscribe to interests</Text>
          <View style={styles.chips}>
            {INTERESTS.map((i) => (
              <Text
                key={i}
                onPress={() => toggleInterest(i)}
                style={[styles.chip, picked.includes(i) && styles.chipOn]}
              >
                {i}
              </Text>
            ))}
          </View>
          {error ? <Text style={styles.err}>{error}</Text> : null}
          <Button title="Create account" onPress={submitAccount} loading={loading} />
        </>
      )}

      {step === 3 && (
        <>
          <Text style={styles.info}>
            Upload a clear photo of your driver&apos;s license, passport, or state ID. This
            prototype simulates scanning without storing real images.
          </Text>
          <Button title="Upload ID (mock)" onPress={submitIdMock} loading={loading} />
          {error ? <Text style={styles.err}>{error}</Text> : null}
        </>
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  title: { fontSize: 26, fontWeight: "700", color: colors.text },
  step: { color: colors.textMuted, marginBottom: 16 },
  info: { color: colors.textMuted, marginBottom: 16, lineHeight: 20 },
  label: { fontWeight: "600", marginBottom: 8, color: colors.text },
  chips: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 16 },
  chip: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: colors.border,
    color: colors.text,
    overflow: "hidden",
  },
  chipOn: { backgroundColor: colors.teal, color: "#fff" },
  err: { color: colors.danger, marginBottom: 8 },
});
