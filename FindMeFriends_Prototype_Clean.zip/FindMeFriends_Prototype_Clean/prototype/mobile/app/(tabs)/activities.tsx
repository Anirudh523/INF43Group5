import { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
} from "react-native";
import { api } from "../../src/api/client";
import { Button } from "../../src/components/Button";
import { Card } from "../../src/components/Card";
import { EmptyState } from "../../src/components/EmptyState";
import { Screen } from "../../src/components/Screen";
import { useAuth } from "../../src/context/AuthContext";
import { useLocation } from "../../src/hooks/useLocation";
import { colors } from "../../src/theme/colors";
import type { Activity } from "../../src/types";

export default function ActivitiesScreen() {
  const { session } = useAuth();
  const { coords, refresh } = useLocation();
  const [list, setList] = useState<Activity[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [joining, setJoining] = useState<string | null>(null);

  const load = useCallback(async () => {
    const c = await refresh();
    const res = await api.getActivities(c.lat, c.lon);
    setList(res.activities);
  }, [refresh]);

  useEffect(() => {
    load().finally(() => setLoading(false));
  }, [load]);

  async function join(id: string) {
    if (!session) return;
    setJoining(id);
    try {
      const res = await api.joinActivity(id, session.userId);
      Alert.alert("Joined", res.message);
      await load();
    } catch (e) {
      Alert.alert("Could not join", e instanceof Error ? e.message : "Error");
    } finally {
      setJoining(null);
    }
  }

  return (
    <Screen>
      <Text style={styles.sub}>Recurring group activities near you</Text>
      <ScrollView
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={async () => {
              setRefreshing(true);
              await load();
              setRefreshing(false);
            }}
          />
        }
      >
        {loading ? (
          <ActivityIndicator color={colors.teal} />
        ) : list.length === 0 ? (
          <EmptyState title="No activities" message="Check back later for new groups." />
        ) : (
          list.map((a) => (
            <Card key={a.id}>
              <Text style={styles.title}>{a.title}</Text>
              <Text style={styles.meta}>{a.schedule}</Text>
              <Text style={styles.meta}>{a.locationName}</Text>
              <Text style={styles.meta}>
                {a.interest} · {a.memberCount}/{a.capacity} members
                {a.distanceKm != null ? ` · ${a.distanceKm} km` : ""}
              </Text>
              {a.full ? (
                <Text style={styles.full}>Group is full</Text>
              ) : (
                <Button
                  title={joining === a.id ? "Joining…" : "Join activity"}
                  onPress={() => join(a.id)}
                  loading={joining === a.id}
                  disabled={!!joining}
                />
              )}
            </Card>
          ))
        )}
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  sub: { color: colors.textMuted, marginBottom: 12, paddingHorizontal: 4 },
  title: { fontSize: 17, fontWeight: "700", color: colors.text },
  meta: { color: colors.textMuted, marginTop: 4 },
  full: { color: colors.danger, marginTop: 8, fontWeight: "600" },
});
