import { router } from "expo-router";
import { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
} from "react-native";
import { api } from "../../src/api/client";
import { Card } from "../../src/components/Card";
import { EmptyState } from "../../src/components/EmptyState";
import { Screen } from "../../src/components/Screen";
import { useAuth } from "../../src/context/AuthContext";
import { colors } from "../../src/theme/colors";
import type { ChatThread } from "../../src/types";

export default function ChatListScreen() {
  const { session } = useAuth();
  const [threads, setThreads] = useState<ChatThread[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!session) return;
    const res = await api.getChatThreads(session.userId);
    setThreads(res.threads);
  }, [session]);

  useEffect(() => {
    load().finally(() => setLoading(false));
  }, [load]);

  return (
    <Screen>
      <ScrollView refreshControl={<RefreshControl refreshing={loading} onRefresh={load} />}>
        {loading ? (
          <ActivityIndicator color={colors.teal} />
        ) : threads.length === 0 ? (
          <EmptyState
            title="No conversations yet"
            message="Message someone from the Discover tab."
          />
        ) : (
          threads.map((t) => (
            <Pressable
              key={t.otherUserId}
              onPress={() =>
                router.push({
                  pathname: "/chat/[otherUserId]",
                  params: { otherUserId: t.otherUserId, name: t.displayName },
                })
              }
            >
              <Card>
                <Text style={styles.name}>{t.displayName}</Text>
                <Text style={styles.preview} numberOfLines={1}>
                  {t.lastMessage}
                </Text>
              </Card>
            </Pressable>
          ))
        )}
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  name: { fontSize: 16, fontWeight: "700", color: colors.text },
  preview: { color: colors.textMuted, marginTop: 4 },
});
