import { router } from "expo-router";
import { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { api } from "../../src/api/client";
import { Card } from "../../src/components/Card";
import { EmptyState } from "../../src/components/EmptyState";
import { MockMap } from "../../src/components/MockMap";
import { Screen } from "../../src/components/Screen";
import { useAuth } from "../../src/context/AuthContext";
import { useLocation } from "../../src/hooks/useLocation";
import { colors } from "../../src/theme/colors";
import type { NearbyUser } from "../../src/types";

export default function MapScreen() {
  const { session } = useAuth();
  const { coords, refresh, loading: locLoading, error: locError } = useLocation();
  const [nearby, setNearby] = useState<NearbyUser[]>([]);
  const [emptyMessage, setEmptyMessage] = useState<string | undefined>();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    if (!session) return;
    const c = await refresh();
    await api.postLocation(session.userId, c.lat, c.lon);
    const res = await api.getNearby(c.lat, c.lon, session.userId);
    setNearby(res.nearby);
    setEmptyMessage(res.emptyMessage);
  }, [session, refresh]);

  useEffect(() => {
    load().finally(() => setLoading(false));
  }, [load]);

  async function onRefresh() {
    setRefreshing(true);
    try {
      await load();
    } finally {
      setRefreshing(false);
    }
  }

  return (
    <Screen>
      <ScrollView
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        {locError ? <Text style={styles.warn}>{locError}</Text> : null}
        {loading || locLoading ? (
          <ActivityIndicator color={colors.teal} style={{ marginVertical: 24 }} />
        ) : (
          <>
            <MockMap nearby={nearby} centerLabel="You · OC" />
            {nearby.length === 0 ? (
              <EmptyState
                title="No one nearby"
                message={
                  emptyMessage ??
                  "Try expanding discovery range or clearing filters in Settings."
                }
              />
            ) : (
              nearby.map((u) => (
                <Card key={u.userId}>
                  <Text style={styles.name}>{u.displayName}</Text>
                  <Text style={styles.meta}>
                    {u.distanceKm} km · {u.interests?.join(", ") || "No interests"}
                  </Text>
                  {u.bio ? <Text style={styles.bio}>{u.bio}</Text> : null}
                  {u.isPrivate ? (
                    <Text style={styles.private}>Private profile</Text>
                  ) : null}
                  <Pressable
                    onPress={() =>
                      router.push({
                        pathname: "/chat/[otherUserId]",
                        params: { otherUserId: u.userId, name: u.displayName },
                      })
                    }
                  >
                    <Text style={styles.chatLink}>Message →</Text>
                  </Pressable>
                </Card>
              ))
            )}
          </>
        )}
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  warn: { color: colors.warning, marginBottom: 8, fontSize: 13 },
  name: { fontSize: 17, fontWeight: "700", color: colors.text },
  meta: { color: colors.textMuted, marginTop: 4 },
  bio: { marginTop: 8, color: colors.text, lineHeight: 20 },
  private: { marginTop: 6, fontStyle: "italic", color: colors.textMuted },
  chatLink: { marginTop: 10, color: colors.tealDark, fontWeight: "600" },
});
