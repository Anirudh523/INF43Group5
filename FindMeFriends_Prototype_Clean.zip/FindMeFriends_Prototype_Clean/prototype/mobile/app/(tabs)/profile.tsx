import { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, Alert, StyleSheet, Text, View } from "react-native";
import { api } from "../../src/api/client";
import { Button } from "../../src/components/Button";
import { Card } from "../../src/components/Card";
import { Input } from "../../src/components/Input";
import { Screen } from "../../src/components/Screen";
import { useAuth } from "../../src/context/AuthContext";
import { colors } from "../../src/theme/colors";

const PROMPTS = [
  "My favorite weekend activity is ___",
  "I'm looking for friends who enjoy ___",
  "A fun fact about me: ___",
];

export default function ProfileScreen() {
  const { session } = useAuth();
  const [bio, setBio] = useState("");
  const [isPublic, setIsPublic] = useState(true);
  const [interests, setInterests] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    if (!session) return;
    const p = await api.getProfile(session.userId);
    setBio(p.bio ?? "");
    setIsPublic(p.isPublic);
    setInterests(p.interests ?? []);
  }, [session]);

  useEffect(() => {
    load().finally(() => setLoading(false));
  }, [load]);

  function usePrompt(p: string) {
    setBio(p);
  }

  async function save() {
    if (!session) return;
    setError("");
    setSaving(true);
    try {
      await api.patchProfile(session.userId, { bio, isPublic, interests });
      Alert.alert("Saved", "Your profile was updated.");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Save failed");
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <Screen>
        <ActivityIndicator color={colors.teal} />
      </Screen>
    );
  }

  return (
    <Screen scroll>
      <Card>
        <Text style={styles.name}>{session?.displayName}</Text>
        <Text style={styles.meta}>
          ID verified: {session?.idVerified ? "Yes (mock)" : "Pending"}
        </Text>
        <Text style={styles.meta}>Visibility: {isPublic ? "Public" : "Private"}</Text>
      </Card>

      <Text style={styles.section}>Edit bio</Text>
      <Input
        label="Bio"
        value={bio}
        onChangeText={setBio}
        multiline
        numberOfLines={4}
        error={error}
        placeholder="Hobbies, goals, boundaries…"
      />
      <Text style={styles.section}>Bio prompts</Text>
      {PROMPTS.map((p) => (
        <Text key={p} style={styles.prompt} onPress={() => usePrompt(p)}>
          {p}
        </Text>
      ))}
      <View style={styles.row}>
        <Button
          title={isPublic ? "Switch to private" : "Switch to public"}
          variant="secondary"
          onPress={() => setIsPublic(!isPublic)}
        />
      </View>
      <Button title="Save profile" onPress={save} loading={saving} />
    </Screen>
  );
}

const styles = StyleSheet.create({
  name: { fontSize: 20, fontWeight: "700", color: colors.text },
  meta: { color: colors.textMuted, marginTop: 4 },
  section: { fontWeight: "600", marginTop: 8, marginBottom: 8, color: colors.text },
  prompt: {
    color: colors.tealDark,
    marginBottom: 8,
    paddingVertical: 6,
  },
  row: { marginVertical: 8 },
});
