import { router } from "expo-router";
import { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  StyleSheet,
  Switch,
  Text,
  View,
} from "react-native";
import { api } from "../../src/api/client";
import { Button } from "../../src/components/Button";
import { Card } from "../../src/components/Card";
import { Screen } from "../../src/components/Screen";
import { useAuth } from "../../src/context/AuthContext";
import { colors } from "../../src/theme/colors";
import type { Settings } from "../../src/types";

const GENDER_OPTIONS = [
  { id: "any", label: "Any" },
  { id: "woman", label: "Women" },
  { id: "man", label: "Men" },
  { id: "non-binary", label: "Non-binary" },
];

export default function SettingsScreen() {
  const { session, signOut } = useAuth();
  const [settings, setSettings] = useState<Settings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    if (!session) return;
    setSettings(await api.getSettings(session.userId));
  }, [session]);

  useEffect(() => {
    load().finally(() => setLoading(false));
  }, [load]);

  async function save(patch: Partial<Settings>) {
    if (!session || !settings) return;
    setSaving(true);
    try {
      const res = await api.patchSettings(session.userId, patch);
      setSettings(res.settings);
      Alert.alert("Saved", "Settings updated.");
    } catch (e) {
      Alert.alert("Error", e instanceof Error ? e.message : "Could not save");
    } finally {
      setSaving(false);
    }
  }

  function expandSearch() {
    if (!settings) return;
    save({
      filters: { ...settings.filters, ageMin: 18, ageMax: 99, genders: ["any"] },
      discoveryRadiusKm: Math.min(100, settings.discoveryRadiusKm + 15),
    });
  }

  if (loading || !settings) {
    return (
      <Screen>
        <ActivityIndicator color={colors.teal} />
      </Screen>
    );
  }

  return (
    <Screen scroll>
      <Card>
        <Text style={styles.label}>Discovery range</Text>
        <Text style={styles.value}>{settings.discoveryRadiusKm} km</Text>
        <View style={styles.row}>
          <Button
            title="− 5 km"
            variant="secondary"
            onPress={() =>
              save({ discoveryRadiusKm: Math.max(1, settings.discoveryRadiusKm - 5) })
            }
          />
          <Button
            title="+ 5 km"
            variant="secondary"
            onPress={() =>
              save({ discoveryRadiusKm: Math.min(100, settings.discoveryRadiusKm + 5) })
            }
          />
        </View>
      </Card>

      <Card>
        <View style={styles.switchRow}>
          <Text style={styles.label}>Public profile</Text>
          <Switch
            value={settings.isPublic}
            onValueChange={(v) => save({ isPublic: v })}
            trackColor={{ true: colors.teal }}
          />
        </View>
      </Card>

      <Card>
        <Text style={styles.label}>Filters (age)</Text>
        <Text style={styles.value}>
          Ages {settings.filters.ageMin}–{settings.filters.ageMax}
        </Text>
        <View style={styles.row}>
          <Button
            title="Younger range"
            variant="secondary"
            onPress={() =>
              save({
                filters: {
                  ...settings.filters,
                  ageMin: 18,
                  ageMax: 28,
                },
              })
            }
          />
          <Button
            title="Expand search"
            onPress={expandSearch}
          />
        </View>
        <Text style={styles.label}>Gender filter</Text>
        {GENDER_OPTIONS.map((g) => {
          const active = settings.filters.genders.includes(g.id);
          return (
            <Text
              key={g.id}
              style={[styles.chip, active && styles.chipOn]}
              onPress={() =>
                save({
                  filters: {
                    ...settings.filters,
                    genders: g.id === "any" ? ["any"] : [g.id],
                  },
                })
              }
            >
              {g.label}
            </Text>
          );
        })}
      </Card>

      <Button title="Save all" onPress={() => save(settings)} loading={saving} />
      <Button
        title="Sign out"
        variant="danger"
        onPress={async () => {
          await signOut();
          router.replace("/(auth)/login");
        }}
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  label: { fontWeight: "600", color: colors.text, fontSize: 15 },
  value: { color: colors.textMuted, marginTop: 4, marginBottom: 8 },
  row: { flexDirection: "row", gap: 8, flexWrap: "wrap" },
  switchRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  chip: {
    padding: 10,
    marginTop: 6,
    borderRadius: 8,
    backgroundColor: colors.border,
    overflow: "hidden",
  },
  chipOn: { backgroundColor: colors.teal, color: "#fff" },
});
