import { Stack } from "expo-router";
import { colors } from "../../src/theme/colors";

export default function ChatStackLayout() {
  return (
    <Stack
      screenOptions={{
        headerShown: false,
        headerStyle: { backgroundColor: colors.navy },
        headerTintColor: "#fff",
      }}
    />
  );
}
