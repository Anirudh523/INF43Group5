import { API_BASE_URL } from "./config";
import type { Activity, ChatMessage, ChatThread, NearbyUser, Settings } from "../types";

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(options?.headers ?? {}),
    },
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `Request failed (${res.status})`);
  }
  return data as T;
}

export const api = {
  health: () => request<{ ok: boolean }>("/health"),

  login: (email: string, password: string) =>
    request<{ ok: boolean; userId: string; displayName: string; idVerified: boolean }>(
      "/api/login",
      { method: "POST", body: JSON.stringify({ email, password }) }
    ),

  register: (body: {
    userId: string;
    email: string;
    password: string;
    firstName: string;
    lastName: string;
    interests?: string[];
  }) =>
    request<{ ok: boolean; userId: string; requiresIdVerification: boolean }>("/api/register", {
      method: "POST",
      body: JSON.stringify(body),
    }),

  verifyId: (userId: string, idImageBase64: string) =>
    request<{ ok: boolean; status: string; message: string }>("/api/id-verify", {
      method: "POST",
      body: JSON.stringify({ userId, idImageBase64 }),
    }),

  postLocation: (userId: string, lat: number, lon: number) =>
    request<{ ok: boolean }>("/api/location", {
      method: "POST",
      body: JSON.stringify({ userId, lat, lon }),
    }),

  getNearby: (lat: number, lon: number, userId: string) =>
    request<{ count: number; nearby: NearbyUser[]; emptyMessage?: string }>(
      `/api/nearby?${new URLSearchParams({
        lat: String(lat),
        lon: String(lon),
        userId,
      })}`
    ),

  getProfile: (userId: string) =>
    request<{ userId: string; displayName: string; bio?: string; interests: string[]; isPublic: boolean }>(
      `/api/users/${userId}`
    ),

  patchProfile: (
    userId: string,
    body: { bio?: string; isPublic?: boolean; interests?: string[]; age?: number; gender?: string }
  ) =>
    request<{ ok: boolean; profile: Record<string, unknown> }>(`/api/profile/${userId}`, {
      method: "PATCH",
      body: JSON.stringify(body),
    }),

  getSettings: (userId: string) => request<Settings>(`/api/settings/${userId}`),

  patchSettings: (userId: string, body: Partial<Settings>) =>
    request<{ ok: boolean; settings: Settings }>(`/api/settings/${userId}`, {
      method: "PATCH",
      body: JSON.stringify(body),
    }),

  getActivities: (lat?: number, lon?: number, interest?: string) => {
    const q = new URLSearchParams();
    if (lat != null) q.set("lat", String(lat));
    if (lon != null) q.set("lon", String(lon));
    if (interest) q.set("interest", interest);
    return request<{ activities: Activity[] }>(`/api/activities?${q}`);
  },

  joinActivity: (activityId: string, userId: string) =>
    request<{ ok: boolean; message: string; full?: boolean }>(`/api/activities/${activityId}/join`, {
      method: "POST",
      body: JSON.stringify({ userId }),
    }),

  getChatThreads: (userId: string) =>
    request<{ threads: ChatThread[] }>(`/api/chat/threads/${userId}`),

  getChatMessages: (userId: string, otherUserId: string) =>
    request<{ messages: ChatMessage[] }>(`/api/chat/${userId}/${otherUserId}`),

  sendMessage: (userId: string, otherUserId: string, text: string) =>
    request<{ ok: boolean; message: ChatMessage }>(`/api/chat/${userId}/${otherUserId}`, {
      method: "POST",
      body: JSON.stringify({ text }),
    }),

  reportUser: (userId: string, otherUserId: string) =>
    request<{ ok: boolean; message: string }>(`/api/chat/${userId}/${otherUserId}/report`, {
      method: "POST",
      body: JSON.stringify({}),
    }),
};
