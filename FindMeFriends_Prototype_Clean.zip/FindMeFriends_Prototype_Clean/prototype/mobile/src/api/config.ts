import Constants from "expo-constants";
import { Platform } from "react-native";

/**
 * API base URL for Node.js server (HTTPS+JSON in production per architecture PDF).
 * - iOS simulator: localhost
 * - Android emulator: 10.0.2.2
 * - Physical device: set EXPO_PUBLIC_API_URL to your PC's LAN IP, e.g. http://192.168.1.5:3000
 */
function defaultHost(): string {
  if (Platform.OS === "android") return "http://10.0.2.2:3000";
  return "http://localhost:3000";
}

export const API_BASE_URL =
  process.env.EXPO_PUBLIC_API_URL ??
  Constants.expoConfig?.extra?.apiUrl ??
  defaultHost();
