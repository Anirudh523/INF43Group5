import React from "react";
import { StyleSheet, Text, View } from "react-native";
import { colors } from "../theme/colors";
import type { NearbyUser } from "../types";

/**
 * MOCK: Google Maps / vendor SDK (architecture PDF).
 * Real app would embed Maps SDK with markers from /api/nearby.
 */
export function MockMap({ nearby, centerLabel }: { nearby: NearbyUser[]; centerLabel?: string }) {
  return (
    <View style={styles.map}>
      <Text style={styles.badge}>Mock map · Google Maps SDK (not connected)</Text>
      <Text style={styles.center}>{centerLabel ?? "Your location"}</Text>
      {nearby.slice(0, 5).map((u) => (
        <View
          key={u.userId}
          style={[
            styles.pin,
            {
              left: `${15 + (u.userId.length % 5) * 14}%`,
              top: `${20 + (u.distanceKm % 4) * 12}%`,
            },
          ]}
        >
          <Text style={styles.pinText}>{u.displayName.split(" ")[0]}</Text>
        </View>
      ))}
      {nearby.length === 0 ? (
        <Text style={styles.hint}>No pins — widen range or adjust filters</Text>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  map: {
    height: 200,
    backgroundColor: "#D4E4F7",
    borderRadius: 14,
    marginBottom: 16,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: colors.border,
  },
  badge: {
    position: "absolute",
    top: 8,
    left: 8,
    fontSize: 10,
    backgroundColor: colors.navy,
    color: "#fff",
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    overflow: "hidden",
    zIndex: 2,
  },
  center: {
    position: "absolute",
    bottom: 12,
    alignSelf: "center",
    left: "35%",
    fontSize: 12,
    color: colors.navy,
    fontWeight: "600",
  },
  pin: {
    position: "absolute",
    backgroundColor: colors.teal,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 20,
  },
  pinText: { color: "#fff", fontSize: 11, fontWeight: "600" },
  hint: {
    position: "absolute",
    bottom: 40,
    width: "100%",
    textAlign: "center",
    color: colors.textMuted,
    fontSize: 12,
  },
});
