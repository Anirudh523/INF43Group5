import React from "react";
import { ScrollView, StyleSheet, View, ViewStyle } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { colors } from "../theme/colors";

export function Screen({
  children,
  scroll,
  style,
}: {
  children: React.ReactNode;
  scroll?: boolean;
  style?: ViewStyle;
}) {
  const content = scroll ? (
    <ScrollView contentContainerStyle={[styles.scroll, style]}>{children}</ScrollView>
  ) : (
    <View style={[styles.inner, style]}>{children}</View>
  );
  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      {content}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  inner: { flex: 1, padding: 16 },
  scroll: { padding: 16, paddingBottom: 32 },
});
