/** Brand colors aligned with team Canva mockup / course slides (#1B2A4A, #02C39A). */
export const colors = {
  navy: "#1B2A4A",
  teal: "#02C39A",
  tealDark: "#059669",
  background: "#F4F7FB",
  card: "#FFFFFF",
  text: "#1B2A4A",
  textMuted: "#64748B",
  border: "#E2E8F0",
  danger: "#DC2626",
  warning: "#F59E0B",
};
