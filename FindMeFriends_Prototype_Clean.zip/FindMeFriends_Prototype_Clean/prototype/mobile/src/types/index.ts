export type UserSession = {
  userId: string;
  displayName: string;
  idVerified: boolean;
};

export type NearbyUser = {
  userId: string;
  displayName: string;
  distanceKm: number;
  bio?: string | null;
  interests?: string[];
  lat?: number;
  lon?: number;
  isPrivate?: boolean;
};

export type Activity = {
  id: string;
  title: string;
  interest: string;
  schedule: string;
  locationName: string;
  capacity: number;
  memberCount: number;
  spotsLeft: number;
  full: boolean;
  recurring: boolean;
  distanceKm: number | null;
};

export type ChatThread = {
  otherUserId: string;
  displayName: string;
  lastMessage: string;
  lastAt?: string;
};

export type ChatMessage = {
  id: string;
  fromUserId: string;
  toUserId: string;
  text: string;
  createdAt: string;
};

export type Settings = {
  discoveryRadiusKm: number;
  isPublic: boolean;
  filters: {
    ageMin: number;
    ageMax: number;
    genders: string[];
  };
};
