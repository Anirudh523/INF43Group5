/**
 * FindMe Friends — HW2 prototype API.
 * Architecture: Node.js on Linux/PaaS, HTTPS+JSON to mobile (Expo React Native).
 * Data: in-memory Map (prototype stand-in for SQL).
 */
import express from "express";
import cors from "cors";
import {
  users,
  activities,
  chats,
  haversineKm,
  createUser,
  publicUserFields,
  seedDemoData,
  nextActivityId,
  nextMessageId,
  chatKey,
  matchesFilters,
} from "./store.js";

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: "2mb" }));

seedDemoData();

function isValidName(name) {
  if (!name || typeof name !== "string") return false;
  const t = name.trim();
  return t.length >= 2 && /^[a-zA-Z][a-zA-Z\s'-]+$/.test(t);
}

function userOr404(userId, res) {
  const u = users.get(userId);
  if (!u) {
    res.status(404).json({ error: "unknown user" });
    return null;
  }
  return u;
}

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "findme-api", users: users.size, activities: activities.size });
});

/** Mock ID verification service (architecture: external vendor). */
app.post("/api/id-verify", (req, res) => {
  const { userId, idImageBase64 } = req.body || {};
  const u = userOr404(userId, res);
  if (!u) return;
  if (!idImageBase64 || String(idImageBase64).length < 20) {
    return res.status(400).json({
      error: "Please upload a clear photo of your government-issued ID.",
      status: "rejected",
    });
  }
  u.idVerified = true;
  u.idVerifiedAt = new Date().toISOString();
  res.json({
    ok: true,
    status: "approved",
    message: "ID verified (mock). Name matches registration.",
  });
});

app.post("/api/register", (req, res) => {
  const {
    userId,
    email,
    password,
    firstName,
    lastName,
    displayName,
    interests,
  } = req.body || {};
  if (!userId || !email || !password) {
    return res.status(400).json({ error: "userId, email, and password required" });
  }
  if (!isValidName(firstName) || !isValidName(lastName)) {
    return res.status(400).json({
      error: "Please enter a valid first and last name (real names required).",
    });
  }
  if (users.has(userId)) {
    return res.status(409).json({ error: "userId already exists" });
  }
  const record = {
    userId,
    email,
    password,
    firstName: firstName.trim(),
    lastName: lastName.trim(),
    displayName: displayName ?? `${firstName.trim()} ${lastName.trim()}`,
    lat: null,
    lon: null,
    bio: "",
    isPublic: true,
    interests: Array.isArray(interests) ? interests : [],
    discoveryRadiusKm: 25,
    idVerified: false,
    filters: { ageMin: 18, ageMax: 99, genders: ["any"] },
    age: null,
    gender: null,
    updatedAt: null,
  };
  createUser(record);
  res.status(201).json({ ok: true, userId, requiresIdVerification: true });
});

app.post("/api/login", (req, res) => {
  const { email, password } = req.body || {};
  for (const u of users.values()) {
    if (u.email === email && u.password === password) {
      return res.json({
        ok: true,
        userId: u.userId,
        displayName: u.displayName,
        idVerified: !!u.idVerified,
      });
    }
  }
  res.status(401).json({ error: "Invalid email or password" });
});

app.post("/api/location", (req, res) => {
  const { userId, lat, lon } = req.body || {};
  const u = userOr404(userId, res);
  if (!u) return;
  if (lat == null || lon == null) {
    return res.status(400).json({ error: "lat, lon required" });
  }
  u.lat = Number(lat);
  u.lon = Number(lon);
  u.updatedAt = new Date().toISOString();
  res.json({ ok: true, received: { lat: u.lat, lon: u.lon } });
});

app.get("/api/nearby", (req, res) => {
  const lat = Number(req.query.lat);
  const lon = Number(req.query.lon);
  const excludeUserId = req.query.userId || null;
  if (Number.isNaN(lat) || Number.isNaN(lon)) {
    return res.status(400).json({ error: "lat and lon required" });
  }
  const viewer = excludeUserId ? users.get(excludeUserId) : null;
  const radiusKm =
    viewer?.discoveryRadiusKm ?? (Number(req.query.radiusKm) || 25);

  const list = [];
  for (const u of users.values()) {
    if (excludeUserId && u.userId === excludeUserId) continue;
    if (u.lat == null || u.lon == null) continue;
    if (viewer && !matchesFilters(viewer, u)) continue;
    const d = haversineKm(lat, lon, u.lat, u.lon);
    if (d <= radiusKm) {
      list.push({
        ...publicUserFields(u),
        distanceKm: Math.round(d * 10) / 10,
        lat: u.lat,
        lon: u.lon,
        interests: u.interests,
      });
    }
  }
  list.sort((a, b) => a.distanceKm - b.distanceKm);
  if (list.length === 0) {
    return res.json({
      count: 0,
      nearby: [],
      emptyMessage:
        "No friends found nearby that match these filters. Try expanding your discovery range in Settings.",
    });
  }
  res.json({ count: list.length, nearby: list });
});

app.get("/api/users/:userId", (req, res) => {
  const u = userOr404(req.params.userId, res);
  if (!u) return;
  res.json({
    ...publicUserFields(u),
    interests: u.interests,
    isPublic: u.isPublic,
    idVerified: !!u.idVerified,
  });
});

app.patch("/api/profile/:userId", (req, res) => {
  const u = userOr404(req.params.userId, res);
  if (!u) return;
  const { bio, isPublic, interests, age, gender } = req.body || {};
  if (typeof bio === "string") {
    const blocked = /\b(http|www\.|fuck|shit)\b/i;
    if (blocked.test(bio)) {
      return res.status(400).json({
        error: "Your bio contains prohibited language or an external link. Please revise.",
      });
    }
    u.bio = bio.slice(0, 500);
  }
  if (typeof isPublic === "boolean") u.isPublic = isPublic;
  if (Array.isArray(interests)) u.interests = interests;
  if (typeof age === "number") u.age = age;
  if (typeof gender === "string") u.gender = gender;
  res.json({
    ok: true,
    profile: {
      userId: u.userId,
      bio: u.bio,
      isPublic: u.isPublic,
      interests: u.interests,
      age: u.age,
      gender: u.gender,
    },
  });
});

app.get("/api/settings/:userId", (req, res) => {
  const u = userOr404(req.params.userId, res);
  if (!u) return;
  res.json({
    discoveryRadiusKm: u.discoveryRadiusKm ?? 25,
    isPublic: u.isPublic,
    filters: u.filters ?? { ageMin: 18, ageMax: 99, genders: ["any"] },
  });
});

app.patch("/api/settings/:userId", (req, res) => {
  const u = userOr404(req.params.userId, res);
  if (!u) return;
  const { discoveryRadiusKm, isPublic, filters } = req.body || {};
  if (typeof discoveryRadiusKm === "number") {
    u.discoveryRadiusKm = Math.min(100, Math.max(1, discoveryRadiusKm));
  }
  if (typeof isPublic === "boolean") u.isPublic = isPublic;
  if (filters && typeof filters === "object") {
    u.filters = {
      ageMin: filters.ageMin ?? u.filters?.ageMin ?? 18,
      ageMax: filters.ageMax ?? u.filters?.ageMax ?? 99,
      genders: filters.genders ?? u.filters?.genders ?? ["any"],
    };
  }
  res.json({ ok: true, settings: awaitSettings(u) });
});

function awaitSettings(u) {
  return {
    discoveryRadiusKm: u.discoveryRadiusKm,
    isPublic: u.isPublic,
    filters: u.filters,
  };
}

app.get("/api/activities", (req, res) => {
  const lat = req.query.lat != null ? Number(req.query.lat) : null;
  const lon = req.query.lon != null ? Number(req.query.lon) : null;
  const interest = req.query.interest;
  const list = [];
  for (const a of activities.values()) {
    if (interest && a.interest !== interest) continue;
    let distanceKm = null;
    if (lat != null && lon != null && a.lat != null) {
      distanceKm = Math.round(haversineKm(lat, lon, a.lat, a.lon) * 10) / 10;
    }
    list.push({
      id: a.id,
      title: a.title,
      interest: a.interest,
      schedule: a.schedule,
      locationName: a.locationName,
      capacity: a.capacity,
      memberCount: a.memberIds.length,
      spotsLeft: a.capacity - a.memberIds.length,
      full: a.memberIds.length >= a.capacity,
      recurring: a.recurring,
      distanceKm,
      memberIds: a.memberIds,
    });
  }
  list.sort((a, b) => (a.distanceKm ?? 999) - (b.distanceKm ?? 999));
  res.json({ activities: list });
});

app.post("/api/activities/:id/join", (req, res) => {
  const { userId } = req.body || {};
  const a = activities.get(req.params.id);
  if (!a) return res.status(404).json({ error: "activity not found" });
  if (!userId) return res.status(400).json({ error: "userId required" });
  if (a.memberIds.length >= a.capacity) {
    return res.status(409).json({
      error: "This group has reached capacity. Browse other recurring activities.",
      full: true,
    });
  }
  if (!a.memberIds.includes(userId)) a.memberIds.push(userId);
  res.json({
    ok: true,
    message: "You have successfully joined the activity.",
    memberCount: a.memberIds.length,
    spotsLeft: a.capacity - a.memberIds.length,
  });
});

app.get("/api/chat/threads/:userId", (req, res) => {
  const uid = req.params.userId;
  if (!users.has(uid)) return res.status(404).json({ error: "unknown user" });
  const threads = [];
  for (const [key, messages] of chats.entries()) {
    const [a, b] = key.split("|");
    if (a !== uid && b !== uid) continue;
    const otherId = a === uid ? b : a;
    const other = users.get(otherId);
    const last = messages[messages.length - 1];
    threads.push({
      otherUserId: otherId,
      displayName: other?.displayName ?? otherId,
      lastMessage: last?.text ?? "",
      lastAt: last?.createdAt,
    });
  }
  res.json({ threads });
});

app.get("/api/chat/:userId/:otherUserId", (req, res) => {
  const key = chatKey(req.params.userId, req.params.otherUserId);
  res.json({ messages: chats.get(key) ?? [] });
});

app.post("/api/chat/:userId/:otherUserId", (req, res) => {
  const { text } = req.body || {};
  const from = req.params.userId;
  const to = req.params.otherUserId;
  if (!text?.trim()) return res.status(400).json({ error: "text required" });
  const key = chatKey(from, to);
  if (!chats.has(key)) chats.set(key, []);
  const msg = {
    id: nextMessageId(),
    fromUserId: from,
    toUserId: to,
    text: text.trim().slice(0, 2000),
    createdAt: new Date().toISOString(),
  };
  chats.get(key).push(msg);
  res.status(201).json({ ok: true, message: msg });
});

app.post("/api/chat/:userId/:otherUserId/report", (req, res) => {
  res.json({
    ok: true,
    message: "Report submitted (mock). User can no longer contact you in a full implementation.",
  });
});

app.listen(PORT, () => {
  console.log(`FindMe API listening on http://localhost:${PORT}`);
  console.log(`Demo login: alice@example.edu / demo123`);
});
