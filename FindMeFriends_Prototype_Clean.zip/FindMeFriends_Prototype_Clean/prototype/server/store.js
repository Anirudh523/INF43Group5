/**
 * In-memory stand-in for SQL tables (users, activities, messages).
 * Production: replace with PostgreSQL + CRUD as described in architecture PDF.
 */

export const users = new Map();
export const activities = new Map();
/** @type {Map<string, Array<{ id: string, fromUserId: string, toUserId: string, text: string, createdAt: string }>>} */
export const chats = new Map();

let activityIdSeq = 1;
let messageIdSeq = 1;

export function haversineKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const toRad = (d) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

export function createUser(record) {
  users.set(record.userId, record);
  return record;
}

export function publicUserFields(u) {
  const base = {
    userId: u.userId,
    displayName: u.displayName,
    interests: u.interests ?? [],
  };
  if (u.isPublic) {
    return { ...base, bio: u.bio };
  }
  return { ...base, bio: null, isPrivate: true };
}

export function seedDemoData() {
  if (users.size > 0) return;

  const demoUsers = [
    {
      userId: "seed-alice",
      displayName: "Alice Chen",
      firstName: "Alice",
      lastName: "Chen",
      email: "alice@example.edu",
      password: "demo123",
      lat: 33.6846,
      lon: -117.8265,
      bio: "UCI student · hiking & coffee",
      isPublic: true,
      interests: ["hiking", "study"],
      discoveryRadiusKm: 25,
      idVerified: true,
      filters: { ageMin: 18, ageMax: 35, genders: ["any"] },
      age: 22,
      gender: "woman",
    },
    {
      userId: "seed-bob",
      displayName: "Bob Martinez",
      firstName: "Bob",
      lastName: "Martinez",
      email: "bob@example.edu",
      password: "demo123",
      lat: 33.69,
      lon: -117.82,
      bio: "Weekend skier · new to OC",
      isPublic: true,
      interests: ["skiing", "hiking"],
      discoveryRadiusKm: 30,
      idVerified: true,
      filters: { ageMin: 20, ageMax: 40, genders: ["any"] },
      age: 28,
      gender: "man",
    },
    {
      userId: "seed-casey",
      displayName: "Casey Lee",
      firstName: "Casey",
      lastName: "Lee",
      email: "casey@example.edu",
      password: "demo123",
      lat: 33.75,
      lon: -117.87,
      bio: "Private profile — connect via activities",
      isPublic: false,
      interests: ["language"],
      discoveryRadiusKm: 15,
      idVerified: true,
      filters: { ageMin: 18, ageMax: 50, genders: ["any"] },
      age: 24,
      gender: "non-binary",
    },
  ];

  for (const u of demoUsers) {
    createUser({
      ...u,
      updatedAt: new Date().toISOString(),
    });
  }

  const demoActivities = [
    {
      title: "Sunday Irvine Hiking Group",
      interest: "hiking",
      schedule: "Every Sunday 8:00 AM",
      locationName: "Bommer Canyon Trailhead",
      lat: 33.63,
      lon: -117.79,
      capacity: 12,
      memberIds: ["seed-alice"],
      recurring: true,
    },
    {
      title: "UCI Study Session (INF43)",
      interest: "study",
      schedule: "Wednesdays 4:00 PM",
      locationName: "UCI Science Library",
      lat: 33.64,
      lon: -117.84,
      capacity: 8,
      memberIds: [],
      recurring: true,
    },
    {
      title: "Beach Volleyball Pickup",
      interest: "sports",
      schedule: "Saturdays 10:00 AM",
      locationName: "Huntington Beach Pier",
      lat: 33.655,
      lon: -117.999,
      capacity: 10,
      memberIds: ["seed-bob"],
      recurring: true,
    },
  ];

  for (const a of demoActivities) {
    const id = `act-${activityIdSeq++}`;
    activities.set(id, { id, ...a });
  }

  chats.set("seed-alice|seed-bob", [
    {
      id: `msg-${messageIdSeq++}`,
      fromUserId: "seed-alice",
      toUserId: "seed-bob",
      text: "Want to join the hiking group this Sunday?",
      createdAt: new Date(Date.now() - 3600000).toISOString(),
    },
  ]);
}

export function nextActivityId() {
  return `act-${activityIdSeq++}`;
}

export function nextMessageId() {
  return `msg-${messageIdSeq++}`;
}

export function chatKey(a, b) {
  return [a, b].sort().join("|");
}

export function matchesFilters(viewer, candidate) {
  const f = viewer.filters ?? {};
  const ageMin = f.ageMin ?? 0;
  const ageMax = f.ageMax ?? 120;
  if (candidate.age != null && (candidate.age < ageMin || candidate.age > ageMax)) {
    return false;
  }
  const genders = f.genders ?? ["any"];
  if (!genders.includes("any") && candidate.gender && !genders.includes(candidate.gender)) {
    return false;
  }
  return true;
}
