import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createServer } from "node:net";
import { after, before, describe, test } from "node:test";

// Coverage snapshot label required by HW4:
// Last updated: 2026-05-27 (commit unavailable - workspace is not a Git repo)
// These integration tests treat the current Express prototype as a black box.

let baseUrl;
let server;

async function request(path, options = {}) {
  const response = await fetch(`${baseUrl}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(options.headers ?? {}),
    },
  });
  const body = await response.json().catch(() => ({}));
  return { response, body };
}

async function getFreePort() {
  return await new Promise((resolve, reject) => {
    const socket = createServer();
    socket.on("error", reject);
    socket.listen(0, () => {
      const { port } = socket.address();
      socket.close(() => resolve(port));
    });
  });
}

async function waitForServerReady(child) {
  let output = "";

  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      reject(new Error(`API server did not start. Output so far:\n${output}`));
    }, 5000);

    child.stdout.on("data", (chunk) => {
      output += chunk.toString();
      if (output.includes("FindMe API listening")) {
        clearTimeout(timer);
        resolve();
      }
    });

    child.stderr.on("data", (chunk) => {
      output += chunk.toString();
    });

    child.on("exit", (code) => {
      clearTimeout(timer);
      reject(new Error(`API server exited early with code ${code}. Output:\n${output}`));
    });
  });
}

before(async () => {
  const port = await getFreePort();
  baseUrl = `http://127.0.0.1:${port}`;

  server = spawn(process.execPath, ["index.js"], {
    cwd: new URL("..", import.meta.url),
    env: { ...process.env, PORT: String(port) },
    stdio: ["ignore", "pipe", "pipe"],
  });

  await waitForServerReady(server);
});

after(async () => {
  if (server && !server.killed) {
    const exited = new Promise((resolve) => {
      server.once("exit", resolve);
    });
    server.kill();
    await exited;
  }
});

describe("API integration tests", () => {
  test("health endpoint reports seeded prototype data", async () => {
    const { response, body } = await request("/health");

    assert.equal(response.status, 200);
    assert.equal(body.ok, true);
    assert.equal(body.service, "findme-api");
    assert.equal(body.users, 3);
    assert.equal(body.activities, 3);
  });

  test("demo user can log in with seeded credentials", async () => {
    const { response, body } = await request("/api/login", {
      method: "POST",
      body: JSON.stringify({ email: "alice@example.edu", password: "demo123" }),
    });

    assert.equal(response.status, 200);
    assert.equal(body.ok, true);
    assert.equal(body.userId, "seed-alice");
    assert.equal(body.displayName, "Alice Chen");
    assert.equal(body.idVerified, true);
  });

  test("nearby endpoint applies distance search and privacy fields", async () => {
    const { response, body } = await request(
      "/api/nearby?lat=33.6846&lon=-117.8265&userId=seed-alice",
    );

    assert.equal(response.status, 200);
    assert.equal(body.count, 2);
    assert.deepEqual(
      body.nearby.map((user) => user.userId),
      ["seed-bob", "seed-casey"],
    );
    assert.equal(body.nearby[0].bio, "Weekend skier · new to OC");
    assert.equal(body.nearby[1].bio, null);
    assert.equal(body.nearby[1].isPrivate, true);
  });

  test("activity join endpoint updates member count for a non-full group", async () => {
    const { response, body } = await request("/api/activities/act-2/join", {
      method: "POST",
      body: JSON.stringify({ userId: "seed-alice" }),
    });

    assert.equal(response.status, 200);
    assert.equal(body.ok, true);
    assert.equal(body.memberCount, 1);
    assert.equal(body.spotsLeft, 7);
  });

  test("profile moderation rejects external links in bios", async () => {
    const { response, body } = await request("/api/profile/seed-alice", {
      method: "PATCH",
      body: JSON.stringify({ bio: "Find me at http://example.com" }),
    });

    assert.equal(response.status, 400);
    assert.match(body.error, /external link/i);
  });

  test("chat endpoint persists a new message in the current server process", async () => {
    const created = await request("/api/chat/seed-alice/seed-bob", {
      method: "POST",
      body: JSON.stringify({ text: "See you at the hiking group." }),
    });

    assert.equal(created.response.status, 201);
    assert.equal(created.body.message.text, "See you at the hiking group.");

    const listed = await request("/api/chat/seed-alice/seed-bob");
    assert.equal(listed.response.status, 200);
    assert.ok(
      listed.body.messages.some((message) => message.text === "See you at the hiking group."),
    );
  });
});
