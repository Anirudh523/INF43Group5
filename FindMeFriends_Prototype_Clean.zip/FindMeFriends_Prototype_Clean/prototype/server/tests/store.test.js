import assert from "node:assert/strict";
import { beforeEach, describe, test } from "node:test";
import {
  activities,
  chatKey,
  chats,
  createUser,
  haversineKm,
  matchesFilters,
  publicUserFields,
  seedDemoData,
  users,
} from "../store.js";

// Coverage snapshot label required by HW4:
// Last updated: 2026-05-27 (commit unavailable - workspace is not a Git repo)
// These unit tests cover the current mocked in-memory data layer only.

beforeEach(() => {
  users.clear();
  activities.clear();
  chats.clear();
});

describe("store helper unit tests", () => {
  test("haversineKm returns zero for the same coordinates", () => {
    assert.equal(haversineKm(33.6846, -117.8265, 33.6846, -117.8265), 0);
  });

  test("haversineKm returns a realistic Orange County distance", () => {
    const km = haversineKm(33.6846, -117.8265, 33.69, -117.82);

    assert.ok(km > 0.7);
    assert.ok(km < 0.9);
  });

  test("publicUserFields exposes bio for public profiles", () => {
    const fields = publicUserFields({
      userId: "user-public",
      displayName: "Public User",
      bio: "Open profile",
      isPublic: true,
      interests: ["hiking"],
    });

    assert.deepEqual(fields, {
      userId: "user-public",
      displayName: "Public User",
      bio: "Open profile",
      interests: ["hiking"],
    });
  });

  test("publicUserFields hides bio for private profiles", () => {
    const fields = publicUserFields({
      userId: "user-private",
      displayName: "Private User",
      bio: "Should stay hidden",
      isPublic: false,
      interests: ["study"],
    });

    assert.deepEqual(fields, {
      userId: "user-private",
      displayName: "Private User",
      bio: null,
      interests: ["study"],
      isPrivate: true,
    });
  });

  test("matchesFilters rejects candidates outside the viewer age range", () => {
    const viewer = { filters: { ageMin: 21, ageMax: 25, genders: ["any"] } };
    const candidate = { age: 28, gender: "woman" };

    assert.equal(matchesFilters(viewer, candidate), false);
  });

  test("matchesFilters accepts candidates matching a specific gender filter", () => {
    const viewer = { filters: { ageMin: 18, ageMax: 35, genders: ["non-binary"] } };
    const candidate = { age: 24, gender: "non-binary" };

    assert.equal(matchesFilters(viewer, candidate), true);
  });

  test("chatKey is stable regardless of user order", () => {
    assert.equal(chatKey("seed-bob", "seed-alice"), "seed-alice|seed-bob");
    assert.equal(chatKey("seed-alice", "seed-bob"), "seed-alice|seed-bob");
  });

  test("seedDemoData creates the current prototype demo dataset once", () => {
    seedDemoData();
    seedDemoData();

    assert.equal(users.size, 3);
    assert.equal(activities.size, 3);
    assert.equal(chats.size, 1);
    assert.equal(users.get("seed-alice").email, "alice@example.edu");
  });

  test("createUser stores and returns the same record", () => {
    const record = { userId: "new-user", displayName: "New User" };

    assert.equal(createUser(record), record);
    assert.equal(users.get("new-user"), record);
  });
});
